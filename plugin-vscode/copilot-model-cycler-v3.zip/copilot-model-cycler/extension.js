// ================================================================
//  Copilot Model Cycler v3.0
//
//  Comportamiento ante cada evento:
//
//  1. RATE LIMIT detectado (⌘⇧L o automático)
//     → Cicla al siguiente modelo (NO abre nuevo chat)
//     → Envía "Continuar" en el chat actual
//
//  2. ERROR en chat (⌘⇧E o watchdog)
//     → Abre nuevo chat
//     → Lee .prompts/prompt_1.md del workspace
//     → Envía el contenido completo del archivo al nuevo chat
//
//  3. Límite de mensajes (automático vía trackAndSend)
//     → Igual que caso 2: nuevo chat + prompt del archivo
//
//  4. Ciclo de modelos manual (⌘⇧. / ⌘⇧,)
//     → Solo cambia el modelo, sin tocar el chat
// ================================================================

const vscode = require('vscode');
const fs     = require('fs');
const path   = require('path');

// ─── Estado global ────────────────────────────────────────────
const state = {
  currentModelIndex: 0,
  messageCount:      0,
  warningShown:      false,
  statusBar:         null,
  pollTimer:         null,
  lastCopilotOutput: '',
  handlingEvent:     false,   // mutex para evitar doble-trigger
};

// Patrones que indican rate limit en el output de Copilot
const RATE_LIMIT_PATTERNS = [
  /rate.?limit/i,
  /you.ve hit the rate limit/i,
  /switching to auto/i,
  /try again/i,
  /quota exceeded/i,
  /too many requests/i,
];

// Patrones que indican error genérico en el chat
const ERROR_PATTERNS = [
  /request failed/i,
  /network error/i,
  /connection refused/i,
  /service unavailable/i,
  /internal server error/i,
  /context length exceeded/i,
  /maximum context/i,
];

// ─── Activación ───────────────────────────────────────────────
function activate(context) {
  log('Copilot Model Cycler v3.0 activado');

  // Status bar
  state.statusBar = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Right, 100
  );
  state.statusBar.command = 'modelCycler.showStatus';
  state.statusBar.tooltip = [
    'Copilot Model Cycler v3.0',
    '───────────────────────────',
    '⌘⇧L  → Rate limit: ciclar modelo + Continuar',
    '⌘⇧E  → Error: nuevo chat + AGENT_LOOP_PROMPT',
    '⌘⇧R  → Nuevo chat manual + AGENT_LOOP_PROMPT',
    '⌘⇧.  → Siguiente modelo',
    '⌘⇧,  → Modelo anterior',
    '⌘⇧M  → Elegir modelo',
    '───────────────────────────',
    'Click → Estado completo',
  ].join('\n');
  context.subscriptions.push(state.statusBar);

  syncIndexFromCopilotSettings();
  refreshStatusBar();
  if (cfg().showStatusBar) state.statusBar.show();

  // Comandos
  reg(context, 'modelCycler.cycleNext',       () => cycle(+1));
  reg(context, 'modelCycler.cyclePrev',       () => cycle(-1));
  reg(context, 'modelCycler.pickModel',       () => pick());
  reg(context, 'modelCycler.trackAndSend',    () => trackAndSend());
  reg(context, 'modelCycler.resetSession',    () => triggerNewChat({ reason: 'manual' }));
  reg(context, 'modelCycler.handleRateLimit', () => handleRateLimit());
  reg(context, 'modelCycler.handleChatError', () => handleChatError());
  reg(context, 'modelCycler.resetCounter',    () => resetCounter());
  reg(context, 'modelCycler.showStatus',      () => showStatus());

  // Monitoreo automático del output de Copilot
  startCopilotOutputMonitor(context);

  // Reaccionar a cambios de settings
  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(e => {
      if (e.affectsConfiguration('modelCycler') ||
          e.affectsConfiguration('github.copilot.chat')) {
        syncIndexFromCopilotSettings();
        refreshStatusBar();
        if (cfg().showStatusBar) state.statusBar.show();
        else state.statusBar.hide();
      }
    })
  );
}

// ─── Monitor automático de output de Copilot ─────────────────

function startCopilotOutputMonitor(context) {
  const interval = cfg().get('monitoring.pollInterval') ?? 3000;
  if (interval <= 0) {
    log('Monitor automático desactivado (pollInterval=0)');
    return;
  }

  log(`Monitor automático iniciado (cada ${interval}ms)`);

  // Intentar obtener el output channel de Copilot leyendo archivos de log
  // VS Code no expone directamente los canales de otras extensiones,
  // pero podemos leer los archivos de log de la extensión de Copilot
  state.pollTimer = setInterval(async () => {
    if (state.handlingEvent) return;
    await checkCopilotLogs();
  }, interval);

  context.subscriptions.push({
    dispose: () => {
      if (state.pollTimer) clearInterval(state.pollTimer);
    }
  });
}

async function checkCopilotLogs() {
  // Intento 1: leer variables de entorno del proceso de Copilot
  // Intento 2: leer archivos de log de VS Code
  try {
    const logsDir = getVSCodeLogsDir();
    if (!logsDir) return;

    // Buscar logs de Copilot en el directorio de logs de VS Code
    const copilotLogPattern = /copilot/i;
    const dirs = fs.readdirSync(logsDir).filter(d => copilotLogPattern.test(d));

    for (const dir of dirs.slice(-1)) {  // solo el más reciente
      const fullDir = path.join(logsDir, dir);
      const files = fs.readdirSync(fullDir)
        .filter(f => f.endsWith('.log'))
        .sort();

      for (const file of files.slice(-1)) {
        const logPath = path.join(fullDir, file);
        const content = fs.readFileSync(logPath, 'utf8');
        const newContent = content.slice(state.lastCopilotOutput.length);

        if (newContent.length > 0) {
          state.lastCopilotOutput = content;
          await analyzeLogContent(newContent);
        }
      }
    }
  } catch {
    // Silencioso — el monitoreo de logs es best-effort
  }
}

function getVSCodeLogsDir() {
  // VS Code guarda logs en diferentes rutas según el OS
  const home = process.env.HOME || process.env.USERPROFILE || '';
  const candidates = [
    // macOS
    path.join(home, 'Library', 'Application Support', 'Code', 'logs'),
    // Linux
    path.join(home, '.config', 'Code', 'logs'),
    // Windows
    path.join(process.env.APPDATA || '', 'Code', 'logs'),
  ];

  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

async function analyzeLogContent(content) {
  if (state.handlingEvent) return;

  // Verificar rate limit
  const isRateLimit = RATE_LIMIT_PATTERNS.some(p => p.test(content));
  if (isRateLimit) {
    log('⚡ RATE LIMIT detectado en logs de Copilot');
    await handleRateLimit();
    return;
  }

  // Verificar error genérico
  const isError = ERROR_PATTERNS.some(p => p.test(content));
  if (isError) {
    log('🚨 ERROR detectado en logs de Copilot');
    await handleChatError();
  }
}

// ─── HANDLER: Rate Limit ──────────────────────────────────────
//   NO abre nuevo chat. Solo cicla modelo + envía "Continuar"

async function handleRateLimit() {
  if (state.handlingEvent) return;
  state.handlingEvent = true;

  try {
    log('Manejando rate limit...');
    const models    = getModels();
    const resetMode = cfg().get('session.rateLimitCycleTo') || 'next';

    // Determinar el modelo destino (evitar el actual que tiene rate limit)
    let targetIndex;
    if (resetMode === 'top') {
      // Ir al más poderoso disponible que no sea el actual
      targetIndex = 0;
      if (targetIndex === state.currentModelIndex && models.length > 1) {
        targetIndex = 1;
      }
    } else {
      // next: siguiente en la lista
      targetIndex = (state.currentModelIndex + 1) % models.length;
    }

    state.currentModelIndex = targetIndex;
    const newModel = models[targetIndex];

    // 1. Cambiar modelo
    await applyModel(newModel, true);
    const label = labelFor(newModel);

    // 2. Notificación visible
    vscode.window.showWarningMessage(
      `⚡ Rate Limit → Cambiando a ${label}. Enviando "Continuar"...`,
      { modal: false }
    );

    // 3. Enviar "Continuar" en el chat ACTUAL (sin abrir nuevo chat)
    await sleep(600);
    await sendMessageToCurrentChat('Continuar');

    log(`Rate limit manejado. Modelo nuevo: ${newModel}`);
  } finally {
    await sleep(2000);  // cooldown para evitar re-trigger inmediato
    state.handlingEvent = false;
  }
}

// ─── HANDLER: Error en chat ───────────────────────────────────
//   Abre nuevo chat + envía el AGENT_LOOP_PROMPT completo

async function handleChatError() {
  if (state.handlingEvent) return;
  state.handlingEvent = true;

  try {
    log('Manejando error en chat → abriendo nuevo chat con AGENT_LOOP_PROMPT...');
    await triggerNewChat({ reason: 'error' });
  } finally {
    await sleep(3000);
    state.handlingEvent = false;
  }
}

// ─── Abrir nuevo chat + enviar prompt del archivo ─────────────

async function triggerNewChat({ reason = 'manual' }) {
  const models    = getModels();
  const resetMode = cfg().get('session.resetModel') || 'top';
  const delay     = cfg().get('session.continuationDelay') ?? 1000;

  log(`Trigger nuevo chat. Razón: ${reason}`);

  // 1. Cambiar modelo según configuración
  if (models.length > 0) {
    let targetIndex = state.currentModelIndex;
    if (resetMode === 'top')   targetIndex = 0;
    else if (resetMode === 'cycle') targetIndex = (state.currentModelIndex + 1) % models.length;
    state.currentModelIndex = targetIndex;
    await applyModel(models[targetIndex], true);
  }

  // 2. Resetear contadores
  const prevCount    = state.messageCount;
  state.messageCount = 0;
  state.warningShown = false;
  refreshStatusBar();

  // 3. Abrir nuevo chat
  let opened = false;
  try {
    await vscode.commands.executeCommand('workbench.action.chat.newChat');
    opened = true;
    log('Nuevo chat abierto vía workbench.action.chat.newChat');
  } catch {
    try {
      await vscode.commands.executeCommand('workbench.action.chat.open');
      opened = true;
      log('Nuevo chat abierto vía workbench.action.chat.open');
    } catch (err2) {
      log(`Error abriendo nuevo chat: ${err2.message}`);
    }
  }

  // 4. Notificación
  const label  = labelFor(models[state.currentModelIndex] || '');
  const prefix = reason === 'error'
    ? '🚨 Error recuperado'
    : reason === 'limit'
    ? `🔄 Límite de ${prevCount} mensajes`
    : '🔄 Reset manual';

  vscode.window.showInformationMessage(
    `${prefix} → Nuevo chat. Modelo: ${label}`
  );

  // 5. Leer y enviar el AGENT_LOOP_PROMPT desde el archivo
  if (opened) {
    await sleep(delay);
    const promptContent = await readPromptFile();
    if (promptContent) {
      await sendMessageToCurrentChat(promptContent);
    } else {
      // Si no se encontró el archivo, notificar al usuario
      vscode.window.showWarningMessage(
        `Model Cycler: No se encontró el archivo de prompt. ` +
        `Configura "modelCycler.session.promptFilePath" o crea ` +
        `".prompts/prompt_1.md" en tu workspace.`,
        'Abrir Settings'
      ).then(sel => {
        if (sel === 'Abrir Settings') {
          vscode.commands.executeCommand('workbench.action.openSettings',
            'modelCycler.session.promptFilePath');
        }
      });
    }
  }
}

// ─── Leer el archivo de prompt ────────────────────────────────

async function readPromptFile() {
  const relativePath = cfg().get('session.promptFilePath') || '.prompts/prompt_1.md';

  // Buscar en todos los workspace folders
  const folders = vscode.workspace.workspaceFolders || [];
  for (const folder of folders) {
    const fullPath = path.join(folder.uri.fsPath, relativePath);
    try {
      const content = fs.readFileSync(fullPath, 'utf8');
      log(`Prompt leído de: ${fullPath} (${content.length} chars)`);
      return content;
    } catch {
      // No está en este folder, seguir buscando
    }
  }

  // Buscar también como ruta absoluta por si el usuario la configuró así
  try {
    if (path.isAbsolute(relativePath)) {
      const content = fs.readFileSync(relativePath, 'utf8');
      log(`Prompt leído de ruta absoluta: ${relativePath}`);
      return content;
    }
  } catch {}

  log(`Archivo de prompt no encontrado: ${relativePath}`);
  return null;
}

// ─── Enviar mensaje al chat actual ────────────────────────────
//
//  Estrategia (por orden de prioridad):
//  1. workbench.action.chat.open con { query } (si lo soporta la versión)
//  2. Clipboard → focus → paste → acceptInput
//  3. Mostrar botón "Copiar prompt" al usuario

async function sendMessageToCurrentChat(message) {
  log(`Enviando mensaje al chat (${message.length} chars)...`);

  // Método 1: API directa de VS Code con query
  try {
    await vscode.commands.executeCommand('workbench.action.chat.open', {
      query:          message,
      isPartialQuery: false,
    });
    log('Mensaje enviado vía workbench.action.chat.open con query');
    return;
  } catch {
    log('Método 1 falló, intentando método 2 (clipboard)...');
  }

  // Método 2: clipboard + paste + send
  try {
    // Guardar contenido previo del clipboard
    const prevClipboard = await vscode.env.clipboard.readText();

    // Escribir el mensaje en el clipboard
    await vscode.env.clipboard.writeText(message);

    // Asegurarse que el chat esté abierto y enfocado
    await vscode.commands.executeCommand('workbench.action.chat.open');
    await sleep(400);

    // Pegar desde el clipboard
    await vscode.commands.executeCommand('editor.action.clipboardPasteAction');
    await sleep(200);

    // Enviar el mensaje (Enter)
    await vscode.commands.executeCommand('workbench.action.chat.acceptInput');
    await sleep(200);

    // Restaurar el clipboard original
    await vscode.env.clipboard.writeText(prevClipboard);

    log('Mensaje enviado vía clipboard + paste + acceptInput');
    return;
  } catch (err2) {
    log(`Método 2 falló: ${err2.message}`);
  }

  // Método 3: fallback manual — mostrar el mensaje para que el usuario lo copie
  const isBig = message.length > 200;
  const preview = isBig
    ? message.substring(0, 100) + '...'
    : message;

  log(`Ambos métodos fallaron. Mostrando opción manual.`);

  const action = await vscode.window.showWarningMessage(
    `Model Cycler: No se pudo enviar el prompt automáticamente. ` +
    `Copia el prompt y pégalo en el chat.`,
    'Copiar prompt al clipboard',
    'Cancelar'
  );

  if (action === 'Copiar prompt al clipboard') {
    await vscode.env.clipboard.writeText(message);
    vscode.window.showInformationMessage(
      `📋 Prompt copiado (${message.length} chars). Pégalo en el chat con ⌘V.`
    );
  }
}

// ─── Intercepción de Enter → contador de mensajes ─────────────

async function trackAndSend() {
  // Primero enviar el mensaje real
  await vscode.commands.executeCommand('workbench.action.chat.acceptInput');

  // Contar
  state.messageCount++;
  refreshStatusBar();
  log(`Mensaje #${state.messageCount}`);

  // Verificar umbrales
  const maxMsg  = cfg().get('session.maxMessages') ?? 25;
  const warnAt  = cfg().get('session.warningAt')   ?? 20;
  const autoRst = cfg().get('session.autoReset')   ?? true;

  if (maxMsg > 0 && state.messageCount >= maxMsg) {
    if (autoRst) {
      log(`Auto-reset por límite de ${maxMsg} mensajes`);
      await triggerNewChat({ reason: 'limit' });
    } else if (!state.warningShown) {
      state.warningShown = true;
      const sel = await vscode.window.showWarningMessage(
        `⚠️ ${state.messageCount} mensajes en esta sesión. ¿Abrir nuevo chat?`,
        'Sí, abrir nuevo chat',
        'Ignorar'
      );
      if (sel === 'Sí, abrir nuevo chat') {
        await triggerNewChat({ reason: 'limit' });
      }
    }
  } else if (!state.warningShown && state.messageCount >= warnAt) {
    state.warningShown = true;
    const rem = maxMsg - state.messageCount;
    vscode.window.showInformationMessage(
      `ℹ️ Copilot Cycler: ${state.messageCount} mensajes. ` +
      `Nuevo chat automático en ${rem} mensajes.`,
      { modal: false }
    );
  }
}

// ─── Aplicar modelo ───────────────────────────────────────────

async function applyModel(modelId, silent = false) {
  try {
    await vscode.workspace
      .getConfiguration('github.copilot.chat')
      .update('languageModel', modelId, vscode.ConfigurationTarget.Global);

    refreshStatusBar();

    if (!silent && cfg().notifyOnSwitch) {
      const label  = labelFor(modelId);
      const models = getModels();
      const pos    = models.indexOf(modelId);
      vscode.window.showInformationMessage(
        `🤖 Copilot → ${label}  [${pos + 1}/${models.length}]`
      );
    }
  } catch (err) {
    vscode.window.showErrorMessage(
      `Model Cycler: error cambiando modelo → ${err.message}`
    );
  }
}

// ─── Ciclar modelos ───────────────────────────────────────────

async function cycle(direction) {
  const models = getModels();
  if (!models.length) { warnEmptyList(); return; }
  state.currentModelIndex =
    ((state.currentModelIndex + direction) + models.length) % models.length;
  await applyModel(models[state.currentModelIndex]);
}

async function pick() {
  const models  = getModels();
  if (!models.length) { warnEmptyList(); return; }
  const current = getCurrentCopilotModel();
  const items = models.map((m, i) => ({
    label:       (m === current ? '$(circle-filled) ' : '$(circle-outline) ') + labelFor(m),
    description: m,
    detail:      m === current ? '← activo ahora' : undefined,
    index:       i,
  }));
  const sel = await vscode.window.showQuickPick(items, {
    title: 'Copilot Model Cycler — elige modelo',
    placeHolder: 'Filtra por nombre o ID...',
    matchOnDescription: true,
  });
  if (sel) {
    state.currentModelIndex = sel.index;
    await applyModel(models[sel.index]);
  }
}

// ─── Estado y status bar ──────────────────────────────────────

function refreshStatusBar() {
  const models  = getModels();
  const modelId = getCurrentCopilotModel();
  const label   = labelFor(modelId);
  const pos     = models.indexOf(modelId);
  const maxMsg  = cfg().get('session.maxMessages') ?? 25;
  const msgs    = state.messageCount;

  const pct = maxMsg > 0 ? msgs / maxMsg : 0;
  if (pct >= 1)         state.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
  else if (pct >= 0.75) state.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
  else                  state.statusBar.backgroundColor = undefined;

  const posStr = pos >= 0 ? `${pos + 1}/${models.length}` : '?';
  state.statusBar.text = `$(robot) ${label}  💬${msgs}/${maxMsg}  [${posStr}]`;
}

function showStatus() {
  const models   = getModels();
  const modelId  = getCurrentCopilotModel();
  const maxMsg   = cfg().get('session.maxMessages') ?? 25;
  const warnAt   = cfg().get('session.warningAt')   ?? 20;
  const autoRst  = cfg().get('session.autoReset')   ?? true;
  const filePath = cfg().get('session.promptFilePath') || '.prompts/prompt_1.md';
  const resetM   = cfg().get('session.rateLimitCycleTo') || 'next';

  const fileExists = (vscode.workspace.workspaceFolders || []).some(f =>
    fs.existsSync(path.join(f.uri.fsPath, filePath))
  );

  vscode.window.showInformationMessage([
    `🤖 Modelo: ${labelFor(modelId)}`,
    `📊 Posición: ${models.indexOf(modelId) + 1}/${models.length}`,
    `💬 Mensajes: ${state.messageCount}/${maxMsg}`,
    `⚠️  Advertencia en: ${warnAt}`,
    `🔄 Auto-reset: ${autoRst ? 'ON' : 'OFF'}`,
    `📄 Prompt file: ${filePath} ${fileExists ? '✅' : '❌ NO ENCONTRADO'}`,
    `⚡ Rate limit cicla a: ${resetM}`,
    '',
    `Lista: ${models.map(m => labelFor(m)).join(' → ')}`,
  ].join('\n'), { modal: true }, 'OK');
}

function resetCounter() {
  state.messageCount = 0;
  state.warningShown = false;
  refreshStatusBar();
  vscode.window.showInformationMessage('↺ Contador reiniciado.');
}

// ─── Helpers ──────────────────────────────────────────────────

function cfg() {
  return vscode.workspace.getConfiguration('modelCycler');
}

function getModels() {
  return (cfg().get('models') || []).filter(m => typeof m === 'string' && m.trim());
}

function labelFor(modelId) {
  const labels = cfg().get('modelLabels') || {};
  return labels[modelId] || modelId;
}

function getCurrentCopilotModel() {
  return vscode.workspace
    .getConfiguration('github.copilot.chat')
    .get('languageModel') || '';
}

function syncIndexFromCopilotSettings() {
  const models = getModels();
  const active = getCurrentCopilotModel();
  const idx    = models.indexOf(active);
  if (idx >= 0) state.currentModelIndex = idx;
}

function warnEmptyList() {
  vscode.window.showWarningMessage(
    'Model Cycler: lista de modelos vacía. Edita "modelCycler.models".'
  );
}

function reg(ctx, id, fn) {
  ctx.subscriptions.push(vscode.commands.registerCommand(id, fn));
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

const out = vscode.window.createOutputChannel('Copilot Model Cycler');
function log(msg) {
  out.appendLine(`[${new Date().toLocaleTimeString()}] ${msg}`);
}

// ─── Desactivación ────────────────────────────────────────────

function deactivate() {
  if (state.pollTimer) clearInterval(state.pollTimer);
  if (state.statusBar)  state.statusBar.dispose();
  out.dispose();
}

module.exports = { activate, deactivate };
